First, run "npm install" to get all the dependencies
listed in the project's description (package.json).

Then, you can run the backend and frontend using VSCode.
You can even debug your client-code (inside the HTML) and server!